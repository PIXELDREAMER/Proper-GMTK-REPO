using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveSpawner : MonoBehaviour
{
    [Header("Enemy Settings")]
    public GameObject enemyPrefab; // Reference to the enemy prefab
    public List<Transform> spawnPoints = new List<Transform>(); // List of spawn points

    [Header("Wave Settings")]
    public float timeBetweenWaves = 10f; // Time between waves
    public int initialEnemyCount = 20; // Initial number of enemies in the first wave

    [Header("Wave Information")]
    [SerializeField]
    private int waveNumber = 1; // Current wave number
    [SerializeField]
    private int enemiesToSpawn; // Number of enemies to spawn in the current wave
    [SerializeField]
    private int enemiesRemaining; // Number of enemies remaining in the current wave

    void Start()
    {
        // Start the first wave
        StartCoroutine(SpawnWave());
    }

    void Update()
    {
        // Check if all enemies in the current wave are killed
        if (enemiesRemaining <= 0)
        {
            // Start a new wave after a delay
            StartCoroutine(NewWave());
        }
    }

    IEnumerator SpawnWave()
    {
        // Set the number of enemies to spawn in the current wave
        enemiesToSpawn = initialEnemyCount + (waveNumber - 1) * 20;

        // Spawn enemies
        for (int i = 0; i < enemiesToSpawn; i++)
        {
            SpawnEnemy();
            yield return new WaitForSeconds(1f); // Adjust this delay if needed
        }
    }

    void SpawnEnemy()
    {
        // Select a random spawn point
        Transform randomSpawnPoint = spawnPoints[Random.Range(0, spawnPoints.Count)];

        // Instantiate an enemy at the spawn point
        GameObject enemy = Instantiate(enemyPrefab, randomSpawnPoint.position, Quaternion.identity);
        Enemy enemyScript = enemy.GetComponent<Enemy>();

        // Pass a reference to this script to the enemy
        enemyScript.SetWaveSpawner(this);

        enemiesRemaining++;
    }

    IEnumerator NewWave()
    {
        // Wait for a delay before starting the next wave
        yield return new WaitForSeconds(timeBetweenWaves);

        // Increase the wave number
        waveNumber++;

        // Reset the remaining enemies for the new wave
        enemiesRemaining = 0;

        // Start the new wave
        StartCoroutine(SpawnWave());
    }

    // Called by the enemy when it is killed
    public void EnemyKilled()
    {
        enemiesRemaining--;
    }

    // Add a method to dynamically add a new spawn point
    public void AddSpawnPoint(Transform newSpawnPoint)
    {
        spawnPoints.Add(newSpawnPoint);
    }
}
