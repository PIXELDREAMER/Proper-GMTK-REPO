using UnityEngine;

public class GameObjectFlipperMouse : MonoBehaviour
{
    public GameObject objectWithSprite;

    // Update is called once per frame
    void Update()
    {
        // Get the horizontal position of the mouse cursor
        float mouseX = Input.mousePosition.x;

        // Convert the mouse position to world coordinates
        Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(new Vector3(mouseX, 0, 0));

        // Flip the sprite on the y-axis based on the mouse position
        if (mouseWorldPosition.x > objectWithSprite.transform.position.x)
        {
            objectWithSprite.GetComponent<SpriteRenderer>().flipX = false;
        }
        else if (mouseWorldPosition.x < objectWithSprite.transform.position.x)
        {
            objectWithSprite.GetComponent<SpriteRenderer>().flipX = true;
        }
        // No input, maintain the current sprite flip state
        else
        {
            // Do nothing or set a default state if needed
        }
    }
}
