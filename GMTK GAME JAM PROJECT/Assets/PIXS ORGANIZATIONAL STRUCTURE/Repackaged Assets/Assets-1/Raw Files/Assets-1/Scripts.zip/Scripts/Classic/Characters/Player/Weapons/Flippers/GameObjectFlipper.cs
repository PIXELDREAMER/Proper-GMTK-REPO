using UnityEngine;

public class GameObjectFlipper : MonoBehaviour
{
    public Joystick joystick;
    public GameObject objectWithSprite;

    // Update is called once per frame
    void Update()
    {
        // Get horizontal input from the joystick
        float horizontalInput = joystick.Horizontal;

        // Flip the sprite on the y-axis based on horizontal input
        if (horizontalInput > 0)
        {
            objectWithSprite.GetComponent<SpriteRenderer>().flipX = false;
        }
        else if (horizontalInput < 0)
        {
            objectWithSprite.GetComponent<SpriteRenderer>().flipX = true;
        }
        // No input, maintain the current sprite flip state
        else
        {
            // Do nothing or set a default state if needed
        }
    }
}



