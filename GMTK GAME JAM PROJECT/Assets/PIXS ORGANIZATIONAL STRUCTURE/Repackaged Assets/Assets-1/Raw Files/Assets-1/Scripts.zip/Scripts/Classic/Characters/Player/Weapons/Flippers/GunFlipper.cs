using UnityEngine;

public class GunFlipper: MonoBehaviour
{
    public Joystick joystick;
    public float rotationSpeed = 5f;

    // Update is called once per frame
    void Update()
    {
        // Get input values for horizontal and vertical axes
        float horizontalInput = joystick.Horizontal;
        float verticalInput = joystick.Vertical;

        // Calculate the angle based on the input
        float targetAngle = Mathf.Atan2(verticalInput, horizontalInput) * Mathf.Rad2Deg;

        // Invert the angle (rotate 180 degrees)
        targetAngle += 180f;

        // Set the rotation of the gun to face the calculated angle
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, targetAngle));
    }
}
