using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public GameObject pauseCanvas;

    void Start()
    {
        // Ensure the pauseCanvas is initially disabled
        if (pauseCanvas != null)
        {
            pauseCanvas.SetActive(false);
        }
    }

    void Update()
    {
        // Check for the pause button (e.g., 'P' key)
        if (Input.GetKeyDown(KeyCode.P))
        {
            TogglePause();
        }
    }

    public void TogglePause()
    {
        // Toggle the pause state and show/hide the pause canvas
        bool isPaused = !Time.timeScale.Equals(0f);
        Time.timeScale = isPaused ? 0f : 1f;

        if (pauseCanvas != null)
        {
            pauseCanvas.SetActive(isPaused);
        }
    }

    public void ResumeGame()
    {
        // Resume the game (reverse the pause)
        TogglePause();
    }

    // Function to restart the current scene
    public void RestartScene()
    {
        // Get the current active scene name and reload it
        Scene currentScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(currentScene.name);
    }
}

