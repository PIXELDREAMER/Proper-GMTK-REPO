using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunAimerTouchscreen : MonoBehaviour
{
    public float rotationSpeed = 5f; // Adjust this value to control the rotation speed
    public Joystick joystick;

    // Update is called once per frame
    void Update()
    {
        // Get input values for horizontal and vertical axes
        float horizontalInput = joystick.Horizontal;
        float verticalInput = joystick.Vertical;

        // If there is any input, rotate the gun
        if (horizontalInput != 0 || verticalInput != 0)
        {
            // Calculate the target angle based on input
            float targetAngle = Mathf.Atan2(verticalInput, horizontalInput) * Mathf.Rad2Deg;

            // Smoothly rotate the gun towards the target angle
            float angle = Mathf.MoveTowardsAngle(transform.eulerAngles.z, targetAngle, rotationSpeed * Time.deltaTime);

            // Set the new rotation of the gun around the z-axis
            transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
        }
    }
}
