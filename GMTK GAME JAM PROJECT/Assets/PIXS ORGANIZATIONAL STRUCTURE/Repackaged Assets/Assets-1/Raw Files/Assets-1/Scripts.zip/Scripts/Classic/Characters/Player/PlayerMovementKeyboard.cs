using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementKeyboard : MonoBehaviour
{
    public float moveSpeed = 10f;
    public float smoothTime = 0.1f; // Adjust this value for smoother movement
    private Vector2 currentVelocity;
    public Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector2 targetVelocity = new Vector2(horizontal, vertical).normalized * moveSpeed;

        // Smoothly adjust the velocity using Vector2.Lerp
        rb.velocity = Vector2.Lerp(rb.velocity, targetVelocity, smoothTime);

       
    }
}
