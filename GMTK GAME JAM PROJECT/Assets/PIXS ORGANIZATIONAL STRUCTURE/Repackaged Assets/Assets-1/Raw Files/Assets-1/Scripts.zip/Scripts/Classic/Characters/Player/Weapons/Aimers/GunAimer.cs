using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunAimer : MonoBehaviour
{
    private Vector3 initialScale; // Store the initial scale of the gun

    // Start is called before the first frame update
    void Start()
    {
        // Store the initial scale of the gun
        initialScale = transform.localScale;
    }

    // Update is called once per frame
    void Update()
    {
        // Get the mouse position in world coordinates
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        // Calculate the direction from the gun to the mouse cursor
        Vector2 direction = mousePosition - transform.position;

        // Calculate the angle in degrees
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        // Rotate the gun to face the mouse cursor
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        // Maintain the initial scale of the gun
        transform.localScale = initialScale;
    }
}
