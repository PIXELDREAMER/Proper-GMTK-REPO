using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GunAmmunitionLimiter : MonoBehaviour
{
    public int MagazineCounter;
    public int MagazineCounterCurrent;
    public int AmmoPacksInInventory;
    public int TotalAmmoInInventory;

    public ShootProjectiles shootprojectile;
    public GameObject FireButton;
    public bool canShoot = true;

    public float ReloadTimer = 4f;

    public TextMeshProUGUI ammoDisplay;

    void Start()
    {
        //MagazineCounter = 24;
        MagazineCounterCurrent = MagazineCounter;
        
        shootprojectile = GetComponent<ShootProjectiles>();
    }

    void Update()
    {
        MagazineRealTimeCounter();
        TotalAmmoInInventory = AmmoPacksInInventory * MagazineCounter;
        UpdateAmmoDisplay();

    }

    void MagazineRealTimeCounter()
    {
        if (shootprojectile.hasFunctionRun)
        {
            ReduceMagazineCount();
            shootprojectile.hasFunctionRun = false;
        }

        if (MagazineCounterCurrent == 0)
        {
            Reload();
        }
    }

    void Reload()
    {
        StartCoroutine(ReloadCoroutine());
    }

    private bool hasReloaded = false;

    IEnumerator ReloadCoroutine()
    {
        if (!hasReloaded)
        {
            canShoot = false;
            shootprojectile.enabled = false;
            FireButton.SetActive(false);

            yield return new WaitForSeconds(ReloadTimer);

            ReduceAmmoInInventory();
        }
        else
        {
            AmmoPacksInInventory--;
            hasReloaded = false;
            yield break;
        }
    }

    public void ReduceAmmoInInventory()
    {
        if (AmmoPacksInInventory == 0)
        {
            AmmoPacksInInventory = 0;
            shootprojectile.enabled = false;
            FireButton.SetActive(false);
        }
        else
        {
            canShoot = true;
            shootprojectile.enabled = true;
            FireButton.SetActive(true);
            MagazineCounterCurrent = MagazineCounter;
            hasReloaded = true;
        }
    }

    public void ReduceMagazineCount()
    {
        if (MagazineCounterCurrent > 0)
        {
            MagazineCounterCurrent--;
        }
    }

    private void UpdateAmmoDisplay()
    {
        ammoDisplay.text = " " + MagazineCounterCurrent.ToString() + "/" + TotalAmmoInInventory.ToString();
    }
}
