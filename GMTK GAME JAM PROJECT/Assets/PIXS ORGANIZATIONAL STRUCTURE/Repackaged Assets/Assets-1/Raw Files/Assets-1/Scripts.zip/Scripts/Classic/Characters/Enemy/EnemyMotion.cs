using UnityEngine;

public class EnemyMotion : MonoBehaviour
{
    public float followSpeed = 3f; // Adjust the speed as needed
    public float followRange = 10f; // Adjust this range to start following
    public float stopRange = 15f; // Adjust this range to stop following

    private Transform player;
    
    private Rigidbody2D rb;
    private bool isFollowing = false;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        if (distanceToPlayer <= followRange)
        {
            isFollowing = true;
            FollowPlayer();
             
        }
        else if (distanceToPlayer >= stopRange)
        {
            isFollowing = false;
            StopFollowing();
        }
    }

    void FollowPlayer()
    {
        if (isFollowing)
        {
            Vector2 direction = player.position - transform.position;
            direction.Normalize();
            rb.velocity = direction * followSpeed;
        }
    }

    void StopFollowing()
    {
        // Halt the enemy's motion
        rb.velocity = Vector2.zero;
    }
}

