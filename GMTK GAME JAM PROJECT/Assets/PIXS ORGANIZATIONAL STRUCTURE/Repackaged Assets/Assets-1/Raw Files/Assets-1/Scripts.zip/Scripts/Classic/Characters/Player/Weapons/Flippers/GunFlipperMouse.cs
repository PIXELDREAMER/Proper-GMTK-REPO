using UnityEngine;

public class GunFlipperMouse : MonoBehaviour
{
    public float rotationSpeed = 5f;

    // Update is called once per frame
    void Update()
    {
        // Get the mouse position in world coordinates
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        // Calculate the direction from the gun to the mouse cursor
        Vector2 direction = mousePosition - transform.position;

        // Calculate the angle in degrees
        float targetAngle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        // Invert the angle (rotate 180 degrees)
        targetAngle += 180f;

        // Set the rotation of the gun to face the mouse cursor
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, targetAngle));
    }
}
