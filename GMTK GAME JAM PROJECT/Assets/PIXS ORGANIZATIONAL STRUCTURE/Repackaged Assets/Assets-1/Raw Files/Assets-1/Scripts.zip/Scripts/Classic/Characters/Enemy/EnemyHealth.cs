using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int maxHealth = 100;
    public int currentHealth;
    public GameObject myself;

    public HealthBar healthBar;

    // List of objects that can damage the player
    public List<string> damagingObjectsTags;

    // Flag to track whether the player is currently in contact with a damaging object
    private bool isTakingDamage = false;

    // Damage rate per second
    public float damageRate = 20f;

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);
    }

    // Update is called once per frame
    void Update()
    {
        // Continuously damage the player if in contact with a damaging object
        if (isTakingDamage)
        {
            TakeContinuousDamage(damageRate * Time.deltaTime);
        }

        if (currentHealth < 0)
        {
            Death();
        }
    }

    void TakeContinuousDamage(float damage)
    {
        currentHealth -= Mathf.RoundToInt(damage);
        healthBar.SetHealth(currentHealth);

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Check if the colliding object has a tag that can damage the player
        if (damagingObjectsTags.Contains(other.gameObject.tag))
        {
            // Player is in contact with a damaging object
            isTakingDamage = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        // Check if the colliding object has a tag that can damage the player
        if (damagingObjectsTags.Contains(other.gameObject.tag))
        {
            // Player is no longer in contact with a damaging object
            isTakingDamage = false;
        }
    }

    void Death()
    {
        myself.SetActive(false);
    }
}
