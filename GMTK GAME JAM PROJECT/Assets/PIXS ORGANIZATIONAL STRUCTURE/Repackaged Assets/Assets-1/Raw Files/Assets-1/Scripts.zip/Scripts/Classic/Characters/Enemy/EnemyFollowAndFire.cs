using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFollowAndFire : MonoBehaviour
{   public Transform player;
    public float moveSpeed = 3.0f;
    public float fireRate = 1.0f;
    public float detectionRange = 10.0f;
    public GameObject projectilePrefab;
    public Transform firePoint;

    private float nextFireTime = 0.0f;

    void Update()
    {
        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        if (distanceToPlayer <= detectionRange)
        {
            Vector2 direction = (player.position - transform.position).normalized;
            transform.Translate(direction * moveSpeed * Time.deltaTime, Space.World);

            if (Time.time >= nextFireTime)
            {
                Fire();
                nextFireTime = Time.time + 1 / fireRate;
            }
        }
    }

    void Fire()
    {
        GameObject projectile = Instantiate(projectilePrefab, firePoint.position, firePoint.rotation);
        Rigidbody2D rb = projectile.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.velocity = firePoint.right * 10f; // Adjust velocity as needed.
        }
        Destroy(projectile, 2.0f); // Destroy projectile after 2 seconds (adjust as needed).
    }
}
