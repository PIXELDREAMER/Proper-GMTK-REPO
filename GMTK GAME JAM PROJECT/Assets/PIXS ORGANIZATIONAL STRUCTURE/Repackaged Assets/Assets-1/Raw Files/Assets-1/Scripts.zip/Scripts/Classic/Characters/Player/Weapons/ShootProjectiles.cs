using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShootProjectiles : MonoBehaviour
{
    public KeyCode launchKey = KeyCode.Space;
    public GameObject projectilePrefab;
    public GameObject FireButton;
    public Transform barrelEnd;
    public Transform playerTransform;
    public float launchSpeed = 10f;
    public float destroyDelay = 10f;
    public bool hasFunctionRun;

    public bool automaticFire = false; // Toggle for automatic fire
    public float fireRate = 5f; // Bullets per second

    //private bool isFiring = false;

    private bool canFire = true;
    private float nextFireTime;

    [SerializeField]
    private GunAmmunitionLimiter gunammolimiter;
    //private MeleeBehaviour meleebehaviour;

    void Start()
    {
        gunammolimiter = GetComponent<GunAmmunitionLimiter>();
        //meleebehaviour = GetComponent<MeleeBehaviour>();
    }

    public Joystick onScreenJoystick;  // Reference to your on-screen joystick script

    void Update()
    {
        // Check for firing using keyboard input
        if (automaticFire)
        {
            if (Input.GetKey(launchKey) && Time.time > nextFireTime)
            {
                nextFireTime = Time.time + 1f / fireRate;
                LaunchProjectile();
            }
        }
        else
        {
            if (Input.GetKeyDown(launchKey))
            {
                LaunchProjectile();
            }
        }

        // Check for firing using on-screen joystick input
        float joystickHorizontal = onScreenJoystick.Horizontal;
        float joystickVertical = onScreenJoystick.Vertical;

        Vector2 joystickInput = new Vector2(joystickHorizontal, joystickVertical);

        // Check if the joystick input magnitude is above a certain threshold (e.g., 0.8 for full throttle)
        if (joystickInput.magnitude > 0.8f && Time.time > nextFireTime)
        {
            nextFireTime = Time.time + 1f / fireRate;
            LaunchProjectile();
        }
    }

    public void LaunchProjectile()
    {
        if (canFire)
        {
            GameObject projectile = Instantiate(projectilePrefab, barrelEnd.position, barrelEnd.rotation);
            Rigidbody2D rb = projectile.GetComponent<Rigidbody2D>();

            if (rb != null)
            {
                float playerDirection = playerTransform.localScale.x;
                Vector2 launchDirection = (playerDirection > 0) ? barrelEnd.right : -barrelEnd.right;

                rb.velocity = launchDirection * launchSpeed;
                Destroy(projectile, destroyDelay);
                hasFunctionRun = true;
                // meleebehaviour.enabled = false;
            }
            else
            {
                Debug.LogWarning("Rigidbody2D component not found on the projectile prefab.");
            }


            if (transform.parent != null)
            {
                GunAmmunitionLimiter ammoLimiter = transform.parent.GetComponent<GunAmmunitionLimiter>();
                if (ammoLimiter != null)
                {
                    ammoLimiter.ReduceMagazineCount();
                }
            }

            //meleebehaviour.enabled = true;
        }
    }

    public void DisableFiring()
    {
        canFire = false;
    }

    public void EnableFiring()
    {
        canFire = true;
    }

    private bool isFiringWithUIButton = false;

    public void StartContinuousFiring()
    {
        if (automaticFire)
        {
            if (gunammolimiter.canShoot)
            {
                // meleebehaviour.enabled = false;
                isFiringWithUIButton = true;
                StartCoroutine(ContinuousFiringCoroutine());
            }
        }
        else
        {
            if (gunammolimiter.canShoot)
            {
                // meleebehaviour.enabled = false;
                LaunchProjectile();
            }
        }
    }

    public void StopContinuousFiring()
    {
        isFiringWithUIButton = false;
        //meleebehaviour.enabled = true;
    }

    private IEnumerator ContinuousFiringCoroutine()
    {
        while (isFiringWithUIButton)
        {
            LaunchProjectile();
            yield return new WaitForSeconds(1f / fireRate);

            if (!FireButton.activeSelf)
            {
                isFiringWithUIButton = false;
            }
        }
    }

    public void LaunchWithUIButton()
    {
        if (automaticFire)
        {
            while (Time.time > nextFireTime)
            {
                nextFireTime = Time.time + 1f / fireRate;
                LaunchProjectile();
            }
        }
        else
        {
            if (Input.GetKeyDown(launchKey))
            {
                LaunchProjectile();
            }
        }
    }
}

