using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementTouchscreen : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float smoothTime = 0.1f; // Adjust this value for smoother movement
    private Vector2 currentVelocity;
    public Rigidbody2D rb;
    public Joystick joystick; // Make sure to assign the joystick in the Unity Editor

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        // Make sure joystick is assigned before getting input
        if (joystick == null)
        {
            Debug.LogError("Joystick not assigned to PlayerMovementTouchscreen script!");
            return;
        }

        // Get the input from the joystick
        float horizontal = joystick.Horizontal;
        float vertical = joystick.Vertical;

        // Create a movement vector based on the joystick input
        Vector2 targetVelocity = new Vector2(horizontal, vertical).normalized * moveSpeed;

        // Smoothly adjust the velocity using Vector2.Lerp
        rb.velocity = Vector2.Lerp(rb.velocity, targetVelocity, smoothTime);

        // Optionally, if you want to rotate the player based on the movement direction
       
    }
}
