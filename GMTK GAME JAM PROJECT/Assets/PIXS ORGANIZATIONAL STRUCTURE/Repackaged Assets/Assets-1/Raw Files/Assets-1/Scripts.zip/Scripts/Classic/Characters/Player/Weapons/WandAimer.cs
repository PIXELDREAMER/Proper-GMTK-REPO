using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WandAimer : MonoBehaviour
{
    public Transform playerTransform;
    public Transform wandTransform;
    public Transform muzzleTransform;
    public float rotationSpeed = 5f;
    public Joystick joystick;

    private float lastHorizontalInput;

    void Update()
    {
        float horizontalInput = joystick.Horizontal + Input.GetAxis("Horizontal");
        float verticalInput = joystick.Vertical + Input.GetAxis("Vertical");

        Vector3 direction = new Vector3(horizontalInput, verticalInput, 0f);

        if (direction.magnitude > 0.1f)
        {
            FlipPlayer(horizontalInput);

            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            float clampedYRotation = Mathf.Clamp(angle, -30f, 30f);

           // RotateWandAndMuzzle(direction, clampedYRotation);
        }
    }

    void FlipPlayer(float horizontalInput)
    {
        if (horizontalInput < 0f)
        {
            playerTransform.localScale = new Vector3(-1f, 1f, 1f); // Flip left
            FlipMuzzle(false);
        }
        else if (horizontalInput > 0f)
        {
            playerTransform.localScale = new Vector3(1f, 1f, 1f); // Flip right
            FlipMuzzle(true);
        }
    }

    void FlipMuzzle(bool flipRight)
    {
        if (flipRight)
        {
            // Flip the muzzle right
            muzzleTransform.localScale = new Vector3(1f, 1f, 1f);
        }
        else
        {
            // Flip the muzzle left
            muzzleTransform.localScale = new Vector3(-1f, 1f, 1f);
        }
    }

   /* void RotateWandAndMuzzle(Vector3 direction, float clampedYRotation)
    {
        float angleX = Mathf.Atan2(direction.y, direction.z) * Mathf.Rad2Deg;
        float clampedXRotation = Mathf.Clamp(angleX, -30f, 30f);

        float angleY = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg;
        float clampedYRotationY = Mathf.Clamp(angleY, -30f, 30f);

        Quaternion targetRotation = Quaternion.Euler(clampedXRotation, clampedYRotationY, 0f);

        wandTransform.localRotation = Quaternion.Euler(clampedXRotation, clampedYRotationY, 0f);
        muzzleTransform.localRotation = Quaternion.Euler(clampedXRotation, clampedYRotationY, 0f);
    }
   */
}

