using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenuManager : MonoBehaviour
{
    public GameObject creditsCanvas;
    public string scenename;
    // Function to start the game
    public void PlayGame()
    {
        // Replace "GameScene" with the name of your game scene
        SceneManager.LoadScene(scenename);
    }

    // Function to toggle the visibility of the credits canvas
    public void ToggleCredits()
    {
        if (creditsCanvas != null)
        {
            creditsCanvas.SetActive(!creditsCanvas.activeSelf);
        }
    }

    // Function to quit the game
    public void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
