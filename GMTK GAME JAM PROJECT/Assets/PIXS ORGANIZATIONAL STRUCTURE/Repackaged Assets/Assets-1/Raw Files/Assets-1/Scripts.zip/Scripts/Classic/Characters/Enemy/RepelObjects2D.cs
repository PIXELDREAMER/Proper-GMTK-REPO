using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RepelObjects2D : MonoBehaviour
{
    public string targetTag = "Player"; // The tag of the objects to repel
    public float minDistance = 2f; // Minimum distance to maintain between objects
    public float repelForce = 10f; // Force applied to repel the objects

    private Rigidbody2D thisRigidbody;

    void Start()
    {
        // Get the Rigidbody2D component of this object
        thisRigidbody = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Find all target objects by tag
        GameObject[] targets = GameObject.FindGameObjectsWithTag(targetTag);

        foreach (GameObject target in targets)
        {
            // Skip if the target is the same as this object
            if (target != gameObject)
            {
                // Calculate the distance between this object and the target object
                float distance = Vector2.Distance(transform.position, target.transform.position);

                // If the distance is less than the minimum distance, repel the objects
                if (distance < minDistance)
                {
                    Rigidbody2D targetRigidbody = target.GetComponent<Rigidbody2D>();
                    Repel(targetRigidbody);
                }
            }
        }
    }

    void Repel(Rigidbody2D targetRb)
    {
        // Calculate the direction from this object to the target object
        Vector2 repelDirection = (Vector2)transform.position - (Vector2)targetRb.transform.position;

        // Apply a force to both objects to repel them
        thisRigidbody.AddForce(repelDirection.normalized * repelForce * Time.deltaTime);
        targetRb.AddForce(-repelDirection.normalized * repelForce * Time.deltaTime);
    }
}
