using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WeaponHolder : MonoBehaviour
{
    int currentIndex = 0;
    public GameObject[] guns;
    public GameObject weaponHolder;
    public Button switchButton1; // Reference to the first weapon switch button
    public Button switchButton2; // Reference to the second weapon switch button
    public Button switchButton3; // Reference to the third weapon switch button
    public Button switchButton4; // Reference to the fourth weapon switch button
    public Button switchButton5; // Reference to the fifth weapon switch button

    public KeyCode switchKey = KeyCode.K; // Keycode to switch weapons using "K"

    void Start()
    {
        // Initialize the array of guns and deactivate them all except the first one.
        guns = new GameObject[weaponHolder.transform.childCount];
        for (int i = 0; i < guns.Length; i++)
        {
            guns[i] = weaponHolder.transform.GetChild(i).gameObject;
            guns[i].SetActive(false);
        }

        if (guns.Length > 0)
        {
            currentIndex = 0;
            guns[currentIndex].SetActive(true);
        }

        // Attach the switch methods to the button click events
        switchButton1.onClick.AddListener(SwitchToWeapon1);
        switchButton2.onClick.AddListener(SwitchToWeapon2);
        switchButton3.onClick.AddListener(SwitchToWeapon3);
        switchButton4.onClick.AddListener(SwitchToWeapon4);
        switchButton5.onClick.AddListener(SwitchToWeapon5);
    }

    void Update()
    {
        // Check for input to switch weapons using the specified switchKey ("K").
        if (Input.GetKeyDown(switchKey))
        {
            // Toggle between the first, second, third, fourth, and fifth weapons when "K" is pressed.
            if (currentIndex == 0)
            {
                SwitchToWeapon2();
            }
            else if (currentIndex == 1)
            {
                SwitchToWeapon3();
            }
            else if (currentIndex == 2)
            {
                SwitchToWeapon4();
            }
            else if (currentIndex == 3)
            {
                SwitchToWeapon5();
            }
            else if (currentIndex == 4)
            {
                SwitchToWeapon1();
            }
        }
    }

    // Method to switch to the first weapon
    void SwitchToWeapon1()
    {
        SwitchWeapon(0);
    }

    // Method to switch to the second weapon
    void SwitchToWeapon2()
    {
        SwitchWeapon(1);
    }

    // Method to switch to the third weapon
    void SwitchToWeapon3()
    {
        SwitchWeapon(2);
    }

    // Method to switch to the fourth weapon
    void SwitchToWeapon4()
    {
        SwitchWeapon(3);
    }

    // Method to switch to the fifth weapon
    void SwitchToWeapon5()
    {
        SwitchWeapon(4);
    }

    void SwitchWeapon(int newIndex)
    {
        // Deactivate the current weapon.
        guns[currentIndex].SetActive(false);

        // Activate the new weapon.
        guns[newIndex].SetActive(true);

        // Update the current index.
        currentIndex = newIndex;
    }
}
