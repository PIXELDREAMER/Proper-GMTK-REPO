using UnityEngine;

public class Enemy : MonoBehaviour
{
    private WaveSpawner waveSpawner;

    void Start()
    {
        // Find the WaveSpawner in the scene
        waveSpawner = GameObject.FindObjectOfType<WaveSpawner>();
        if (waveSpawner == null)
        {
            Debug.LogError("WaveSpawner not found in the scene!");
        }
    }

    void Update()
    {
        // Add your enemy movement or behavior code here
    }

    // Call this method when the enemy is killed
    public void Die()
    {
        // Notify the WaveSpawner that this enemy is killed
        waveSpawner.EnemyKilled();

        // Optionally, you can add other logic for enemy death (e.g., play death animation, particle effects, etc.)
        Destroy(gameObject);
    }

    public void SetWaveSpawner(WaveSpawner spawner)
    {
        waveSpawner = spawner;
    }
}
